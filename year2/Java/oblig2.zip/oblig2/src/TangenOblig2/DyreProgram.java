package TangenOblig2;

public class DyreProgram {
    public static void main(String[] args) {
        Grensesnitt grensesnitt = new Grensesnitt();
        grensesnitt.meny();
    }
}
