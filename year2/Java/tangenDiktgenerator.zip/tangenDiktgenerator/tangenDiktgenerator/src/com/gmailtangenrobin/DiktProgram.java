package com.gmailtangenrobin;

public class DiktProgram {
    public static void main(String[] args) {
        Grensesnitt grensesnitt = new Grensesnitt();
        grensesnitt.meny();
    }
}
