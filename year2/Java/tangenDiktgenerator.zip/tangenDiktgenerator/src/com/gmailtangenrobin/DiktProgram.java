package com.gmailtangenrobin;

public class DiktProgram {
    //Lager main metode for å starte selve programmet
    public static void main(String[] args) {
        //Lager en lokal instanse av Grensesnitt
        Grensesnitt grensesnitt = new Grensesnitt();
        grensesnitt.meny();
    }
}
