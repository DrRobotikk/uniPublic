package com.gmailtangenrobin;

import javax.swing.*;

public class Grensesnitt {
    //Lager objekt av diktkontroll
    DiktKonrtoll kontroll = new DiktKonrtoll();

    //Lager de forskjellige listene for meny valg
    private final String[] HOVEDMENY = {"Enkelt dikt","avansert dikt","Legg til ord","Avslutt"};
    private final String[] ENKELTMENY = {"Enkelt dikt","tilbake"};
    private final String[] AVANSERTMENY = {"Avansert dikt","tilbake"};
    private final String[] REGISTRERMENY = {"Artikkel","Verb","Substantiv","Adjektiv","Tilbake"};


    //Lagermeny valgene

    public int lesValgHoved(){
        int valg = JOptionPane.showOptionDialog(
                null,
                "Ta et valg",//Ledetekst
                "Diktgenerator",//Tittel på vinduet
                JOptionPane.DEFAULT_OPTION,//Klassekonstant
                JOptionPane.PLAIN_MESSAGE,//Klassekonstant
                null,
                HOVEDMENY,//Valgene
                HOVEDMENY[0]);//Default option
        return valg;

    }
    public int lesValgEnekltMeny(){
        int valg = JOptionPane.showOptionDialog(
                null,
                "Ta et valg",//Ledetekst
                "Diktgenerator",//Tittel på vinduet
                JOptionPane.DEFAULT_OPTION,//Klassekonstant
                JOptionPane.PLAIN_MESSAGE,//Klassekonstant
                null,
                ENKELTMENY,//Valgene
                ENKELTMENY[0]);//Default option
        return valg;

    }
    public int lesValgAvansertMeny(){
        int valg = JOptionPane.showOptionDialog(
                null,
                "Ta et valg",//Ledetekst
                "Diktgenerator",//Tittel på vinduet
                JOptionPane.DEFAULT_OPTION,//Klassekonstant
                JOptionPane.PLAIN_MESSAGE,//Klassekonstant
                null,
                AVANSERTMENY,//Valgene
                AVANSERTMENY[0]);//Default option
        return valg;

    }

    public int lesValgRegistrer(){
        int valg = JOptionPane.showOptionDialog(
                null,
                "Ta et valg",//Ledetekst
                "Diktgenerator",//Tittel på vinduet
                JOptionPane.DEFAULT_OPTION,//Klassekonstant
                JOptionPane.PLAIN_MESSAGE,//Klassekonstant
                null,
                REGISTRERMENY,//Valgene
                REGISTRERMENY[0]);//Default option
        return valg;

    }

    //Lager menyene
    public void meny (){
        kontroll.leggTilIListe();
        boolean fortsette=true;
        while (fortsette){
            int valg=lesValgHoved();

            switch (valg){
                case 0: lagEnkeltDikt();
                break;
                case 1: lagAvansertDikt();
                break;
                case 2: registrereMeny();
                break;
                default: fortsette = false;

            }

        }



    }




    public void registrereMeny (){
        boolean fortsette=true;
        while (fortsette){
            int valg=lesValgRegistrer();

            switch (valg){
                case 0: registrerArtikkel();
                    break;
                case 1: registrerVerb();
                    break;
                case 2: registrerSubstantiv();
                    break;
                case 3: registrerAdjektiv();
                    break;
                default: fortsette = false;

            }

        }



    }



    //metode for enkle diikt
    public void lagEnkeltDikt(){
        String dikt = kontroll.lagEnkeltDikt();
        JOptionPane.showMessageDialog(null,dikt);

    }
    //Metode for enkelt dikt
    public void lagAvansertDikt(){
        String dikt = kontroll.lagAvansertDikt();
        JOptionPane.showMessageDialog(null,dikt);
    }
    //Metoder for å registrere ord
    public void registrerVerb(){
        String nyttVerb = JOptionPane.showInputDialog("Skriv et verb");
        kontroll.registrertVerb(nyttVerb);


    }

    public void registrerAdjektiv(){
        String nyttAdjektiv = JOptionPane.showInputDialog("Skriv et adjektiv");
        kontroll.registrerAdjektiv(nyttAdjektiv);

    }

    public void registrerSubstantiv(){
        String nyttSubstantiv = JOptionPane.showInputDialog("Skriv et substantiv");
        kontroll.registrertSubstantiv(nyttSubstantiv);

    }

    public void registrerArtikkel(){
        String nyArtikkel = JOptionPane.showInputDialog("Skriv inn en artikkel");
        kontroll.registrertArtikkel(nyArtikkel);

    }


}
